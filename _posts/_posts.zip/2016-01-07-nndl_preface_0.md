---
layout: post
title: (번역)신경망과 딥러닝 - 첫페이지
category: neural networks and deep learning
tags: [신경망과 딥러닝, 저자서문, 번역]
---
-**원저자: [Michael Neilson](http://michaelnielsen.org/)**<br>
-**원문주소: [http://neuralnetworksanddeeplearning.com/index.html](http://neuralnetworksanddeeplearning.com/index.html)**<br>
-**역자: [지식믹서기 == 지중현](joonghyunji@gmail.com)**<br>
***본 번역의 무단 전재 및 재배포를 금지합니다.***
<br>
<br>


'‘'신경망과 딥러닝'은 저자가 온라인에 자유롭게 공개한 책이다. 이 책에서 배울 수 있는 것은 다음과 같다.

- 첫째, 관찰 데이터를 통해 컴퓨터를 학습시킬 수 있는, 생물학에서 영감을 얻은 아름다운 프로그래밍 패러다임인 인공 신경망. 
- 둘째, 신경망을 가지고 학습하는 강력한 기법들의 집합인 딥러닝.


현재, 신경망과 딥러닝 기술은 이미지 인식, 음성 인식 및 자연어 처리에 관련된 많은 문제를 푸는데 가장 좋은 해결책이다. 이 책은 신경망과 딥러닝의 핵심적인 개념들 중 많은 것을 가르쳐 줄 것이다. 

이 책에서 어떤 접근법을 사용하는지 좀 더 많은 것을 알고 싶다면 [여기](http://localhost:4000/2016/01/08/nndl_preface_1/)를 참조해라. 아니면 당장 [1장](http://opendemocracymanitoba.ca)부터 시작하면 된다.
